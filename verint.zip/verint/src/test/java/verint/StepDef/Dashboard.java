package verint.StepDef;

import cucumber.api.java.en.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import verint.Page.DashboardPage;
import verint.Profile;
import static verint.WebUtility.*;

public class Dashboard {

    private ChromeDriver _driver = getChromeInstance();
    private Profile _profile = new Profile();

    @Then("^System display menu why verint$")
    public void system_display_menu_why_verint() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-607401\"]/a"));
    }

    @Then("^System display menu blog$")
    public void system_display_menu_blog() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-617070\"]/a"));
    }

    @Then("^System display menu customer login and community$")
    public void system_display_menu_customer_login_and_community() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-500837\"]/a"));
    }

    @Then("^System display menu support$")
    public void system_display_menu_support() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-500833\"]/a"));
    }

    @Then("^System display menu solutions$")
    public void system_display_menu_solutions() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-608209\"]/a"));
    }

    @Then("^System display menu your role$")
    public void system_display_menu_your_role() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-608139\"]/a"));
    }

    @Then("^System display menu customers$")
    public void system_display_menu_customers() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-608163\"]/a"));
    }

    @Then("^System display menu partners$")
    public void system_display_menu_partners() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-608165\"]/a"));
    }

    @Then("^System display menu our company$")
    public void system_display_menu_our_company() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-608168\"]/a"));
    }

    @Then("^System display button contact us$")
    public void system_display_button_contact_us() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"menu-item-608183\"]/a"));
    }

    @Then("^System display verint logo$")
    public void system_display_verint_logo() throws Exception{
        waitForElementVisible(By.xpath("//*[@id=\"siteLogoMain\"]/div/div/div/div/p/a"));
    }

    @Then("^System display icon search$")
    public void system_display_menu_icon_search() throws Exception{
        waitForElementVisible(By.id("nav-toggle"));
    }

    @Given("^User access Dashboad Page$")
    public void user_access_dashboard_page() throws Exception{
        redirectTo(_profile.getUrlDashboard());
    }

    @Then("^System display option menu languange \"([^\"]*)\" selected$")
    public void system_display_menu(String language) throws Exception{
        objectExist(language);
    }

    @When("^User click icon search$")
    public void user_click_icon_search() {
        waitForAction(1000);
        waitAndClick(By.id("nav-toggle"));
    }

    @When("^System display field search$")
    public void system_display_field_search() {
        waitForAction(1000);
        waitForElementVisible(By.id("downshift-0-input"));
    }

    @When("^User input \"([^\"]*)\" on search field$")
    public void user_input_on_search_field(String input) {
        waitForAction(1000);
        waitAndFill(By.id("downshift-0-input"), input);
    }

    @When("^User click button go$")
    public void user_click_button_go() {
        waitForAction(1000);
        waitAndClick(By.xpath("//*[@id=\"nav-search-box\"]/div/form/button"));
    }

    @Then("^User see field search filled with \"([^\"]*)\"$")
    public void user_see_field_search_filled_with(String input) {
        waitForAction(1000);
        Assert.assertEquals(getValue(By.id("downshift-1-input")), input);
    }

    @Then("^User see result article contains \"([^\"]*)\"$")
    public void user_see_result_article_contains(String titleArticle) {
        getTitleArticle(By.xpath("(//h3)[1]")).contains(titleArticle);
    }


}
