package verint.Page;

public class DashboardPage {
}
