package verint;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;

public class WebUtility {

    static {
        System.setProperty("webdriver.chrome.driver", "C:\\driver\\chromedriver.exe");
    }

    private static ChromeDriver _driver;

    public static ChromeDriver getChromeInstance() {
        if (_driver == null) {
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            _driver = new ChromeDriver(options);
        }
        return _driver;
    }


    public static void redirectTo(String url) {
        _driver.navigate().to(url);
    }

    public static void waitForElementVisible(By id) {
        WebDriverWait wait = new WebDriverWait(_driver, 20);
        wait.until(visibilityOfElementLocated(id));
    }

    public static void waitForAction(int millsec) {
        try {
            Thread.sleep(millsec);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void waitAndClick(By id) {
        waitForElementVisible(id);
        waitForAction(800);
        _driver.findElement(id).click();
    }

    public static void waitAndFill(By id, String value) {
        waitForElementVisible(id);
        WebElement element = _driver.findElement(id);
        element.click();
        _driver.findElement(id).sendKeys(Keys.chord(Keys.CONTROL + "a"));
        waitForAction(500);
        _driver.findElement(id).sendKeys(Keys.chord(Keys.DELETE));
        _driver.findElement(id).sendKeys(value);
    }

    public static String getValue(By id) {
        waitForElementVisible(id);
        waitForAction(1000);
        String getValue = _driver.findElement(id).getAttribute("value");
        return getValue;
    }

    public static String getTitleArticle(By xpath) {
        waitForElementVisible(xpath);
        waitForAction(1000);
        String getValue = _driver.findElement(xpath).getText();
        return getValue;
    }

    public static void objectNotExist(By id) {
        assertTrue(_driver.findElements(id).isEmpty());
    }

    public static void objectNotDisplayed(By id) {
        assertFalse(_driver.findElement(id).isDisplayed());
    }

    public static void selectOption(By id, String text) {
        Select option = new Select(_driver.findElement(id));
        waitForAction(300);
        option.selectByVisibleText(text);
    }


    //code untuk check element disable atau tidak
    public static boolean objectDisabled(By id) {
        waitForElementVisible(id);
        waitForAction(1000);
        String classButton = _driver.findElement(id).getAttribute("class");
        boolean result = classButton.contains("disabled");
        return result;
    }


    public static boolean checkLanguange(String language) {
        waitForAction(1000);
        String classButton = _driver.findElement(By.xpath("//*[@title='"+language+"']")).getAttribute("selected");
        boolean result = classButton.equals(language);
        return result;
    }

    public static void objectExist(String language) {
        assertFalse(_driver.findElements(By.xpath("//*[@title='"+language+"'][@selected]")).isEmpty());
    }
    //end of code check disable





    public static void scrollAndClick(By id) {
        ((JavascriptExecutor) _driver).executeScript("arguments[0].click();", _driver.findElement(id));
    }

    public static void clickEnter(By id) {
        WebElement object = _driver.findElement(id);
        object.sendKeys(Keys.ENTER);
    }

}
