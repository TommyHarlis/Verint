package verint;

public class Profile {
    private String urlDashboard = "https://www.verint.com";

    public String getUrlDashboard(){
        return  urlDashboard;
    }


}
